/* ═══════════════════════════════════════════════════════════
   RANCANG UNDANGAN — Backend "Ucapan & Doa" (GRATIS)
   Google Sheets + Apps Script. Satu file ini dipakai per klien.

   CARA PASANG (sekali per klien, ±10 menit, via browser):
   1. Buat Google Sheet baru → beri nama mis. "Ucapan - Budi & Sinta".
      Baris pertama isi:  Nama | Pesan | Waktu
   2. Di Sheet: Ekstensi → Apps Script → hapus isi editor → tempel file ini.
   3. Deploy → Deployment baru → jenis "Aplikasi web":
      - Jalankan sebagai: Saya
      - Yang memiliki akses: Semua orang
      → Salin URL Web App yang muncul.
   4. Tempel URL itu ke WISHES_API_URL di script.js template → push → jadi.
   ═══════════════════════════════════════════════════════════ */

function sheetUcapan() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName("Ucapan");
  if (!sheet) {
    sheet = ss.insertSheet("Ucapan");
    sheet.appendRow(["Nama", "Pesan", "Waktu"]);
  }
  return sheet;
}

// Tamu membuka halaman → ambil daftar ucapan (terbaru di atas)
function doGet() {
  var data = sheetUcapan().getDataRange().getValues();
  var out = [];
  for (var i = data.length - 1; i >= 1; i--) {
    if (data[i][0]) out.push({ nama: data[i][0], pesan: data[i][1] });
  }
  return ContentService
    .createTextOutput(JSON.stringify(out))
    .setMimeType(ContentService.MimeType.JSON);
}

// Tamu mengirim ucapan → simpan satu baris baru
function doPost(e) {
  try {
    var d = JSON.parse(e.postData.contents);
    var nama = String(d.nama || "").slice(0, 40);
    var pesan = String(d.pesan || "").slice(0, 220);
    if (nama && pesan) sheetUcapan().appendRow([nama, pesan, new Date()]);
    return ContentService
      .createTextOutput(JSON.stringify({ ok: true }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ ok: false }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}
